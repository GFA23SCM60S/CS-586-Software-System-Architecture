package PlatformData;

/*
    GasPump2 data storage object responsible for storing key platform-specific data that must be shared between
    system components

    NOTE: For the sake of shorter code and simplicity, fields are accessed directly, instead of through getters and setters
 */
public class DataGasPump2 extends Data {
    public String   gasType;
    public float      R_price;
    public float      D_price;
    public float      P_price;
    public int    cash;
    public float      price;
    public float G;
    public float      total;

    // temporary variables
    public float a;
    public float b;
    public float c;
    public int temp_cash;
}
