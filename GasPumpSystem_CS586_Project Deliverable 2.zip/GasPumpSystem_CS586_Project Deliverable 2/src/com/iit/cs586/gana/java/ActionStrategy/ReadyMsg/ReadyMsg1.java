package ActionStrategy.ReadyMsg;

import PlatformData.Data;
import PlatformData.DataGasPump1;

/*
    GasPump1 ReadyMsg action responsible for printing a ready message
 */
public class ReadyMsg1 extends ReadyMsg {

    public ReadyMsg1(Data data) {
        super(data);
    }

    /*
        Print a message indicating the GasPump is ready to dispense 1 gallon
        of the selected type of gasoline
     */
    @Override
    public void readyMsg() {
        System.out.println("READY TO DISPENSE FUEL");
        System.out.println("Select (8) to dispense 1 gallon of gasoline");
        System.out.println("Otherwise, select (9) to stop");
    }
}
