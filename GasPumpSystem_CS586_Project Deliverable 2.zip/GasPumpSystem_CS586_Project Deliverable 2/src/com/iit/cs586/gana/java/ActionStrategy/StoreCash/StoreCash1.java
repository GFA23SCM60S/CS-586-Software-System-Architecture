package ActionStrategy.StoreCash;

import PlatformData.Data;
import PlatformData.DataGasPump1;
import PlatformData.DataGasPump2;

/*
    GasPump1 StoreCash action --> does nothing under current system design
 */
public class StoreCash1 extends StoreCash {

    public StoreCash1(Data data) {
        super(data);
    }

    /*
        GasPump1 does not support payment with cash, and so this method should never be invoked
        by GasPump1 under the current system design.
        However, in the case that it does get invoked, it will do nothing.
    */
    @Override
    public void storeCash() {
        DataGasPump1 d = (DataGasPump1) data;
        d.cash = d.temp_cash;
        System.out.println("Amount of cash inserted: $" + d.cash);
    }
}
