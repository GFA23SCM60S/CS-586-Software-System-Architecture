/*
@author : Ganapathi Subramaniam Sankaranarayanan
* This is the project source code for CS-586: Software System Architecture
* */
package Main;

import AbstractFactory.*;
import GasPump.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;


public class GasPumpDriver {
    public static void main(String[] args) {
        // Initialize input reader
        BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
        // Print project info
        System.out.println("\nCS586 Project Deliverable 2 Demo\n");
        // Prompt user to select GasPump type
        System.out.println("Select type of GasPump: ");
        System.out.println("1. Gas Pump 1");
        System.out.println("2. Gas Pump 2");

        int pump_type;
        String input = "initial";
        try {
            // Read user input for GasPump type
            pump_type = Integer.parseInt(scan.readLine());
            switch (pump_type) {
                case 1: {// If GasPump 1 is selected
                    // Initialize GasFactory1 and GasPump1 objects
                    GasFactory1 gf1 = new GasFactory1();
                    GasPump1 gp1 = new GasPump1(gf1);

                    // Operation loop for GasPump1
                    while (!input.equals("q")) {
                        // Print available operations
                        gp1.printOperations();
                        // Read user input for operation selection
                        input = scan.readLine();
                        switch (input) {
                            case "0": { // Activate operation
                                // Prompt for price parameter and activate GasPump1
                                // Handle potential NumberFormatException
                                System.out.println("Activate");
                                int a;
                                System.out.println("Enter the price parameter a: ");
                                try {
                                    a = Integer.parseInt(scan.readLine());
                                    gp1.Activate(a);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Price must be a Integer.");
                                }
                                break;
                            } // Other cases for various operations, similar structure follows

                            case "1": { // Start
                                System.out.println("Start");
                                gp1.Start();
                                break;
                            }
                            case "2": { // PayCredit
                                System.out.println("PayCredit");
                                gp1.PayCredit();
                                break;
                            }

                            case "3": { // PayCash
                                System.out.println("PayCash");
                                System.out.println("Insert cash (enter $ amount): ");
                                try {
                                    int cash = Integer.parseInt(scan.readLine());
                                    gp1.PayCash(cash);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Dollar amount must be a integer number");
                                }
                                break;
                            }

                            case "4": { // Reject
                                System.out.println("Reject");
                                gp1.Reject();
                                break;
                            }

                            case "5": { // Cancel
                                System.out.println("Cancel");
                                gp1.Cancel();
                                break;
                            }

                            case "6": { // Approve
                                System.out.println("Approve");
                                gp1.Approve();
                                break;
                            }

                            case "7": { // StartPump
//                                gp1.Regular();
                                System.out.println("StartPump");
                                gp1.StartPump();
                                break;
                            }

                            case "8": { // Pump
                                System.out.println("Pump");
                                gp1.Pump();
                                break;
                            }

                            case "9": { // StopPump
                                System.out.println("StopPump");
                                gp1.StopPump();
                                break;
                            }

                            case "q": { // Quit
                                break;
                            }
                            default: { // Anything else: unknown / unsupported operation
                                System.out.println("Unknown operation: '" + input + "'");
                                System.out.println("Please select a valid operation");
                                break;
                            }
                        }
                    } // End while loop
                    System.out.println("Quitting ...");
                    break;
                } // End pump_type = 1 case
                case 2: {// If GasPump ff2 is selected
                    // Initialize GasFactory2 and GasPump2 objects
                    GasFactory2 gf2 = new GasFactory2();
                    GasPump2 gp2 = new GasPump2(gf2);
                    // Operation loop for GasPump2
                    while (!input.equals("q")) {
                        // Print available operations
                        gp2.printOperations();
                        // Read user input for operation selection
                        input = scan.readLine();
                        switch (input) {
                            case "0": { // Activate
                                System.out.println("Activate(float a, float b, float c)");
                                float a, b, c;
                                System.out.println("Enter the price parameter a: ");
                                try {
                                    a = Float.parseFloat(scan.readLine());
                                    System.out.println("Enter the price parameter b: ");
                                    b = Float.parseFloat(scan.readLine());
                                    System.out.println("Enter the price parameter c: ");
                                    c = Float.parseFloat(scan.readLine());
                                    gp2.Activate(a, b, c);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Price must be an Float.");
                                }// Cases for various operations, similar structure follows
                                break;
                            }
                            case "1": { // Start
                                System.out.println("Start");
                                gp2.Start();
                                break;
                            }
                            case "2": { // PayCash
                                System.out.println("PayCash(int c)");
                                System.out.println("Insert cash (enter $ amount): ");
                                try {
                                    int cash = Integer.parseInt(scan.readLine());
                                    gp2.PayCash(cash);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Dollar amount must be a floating point decimal number");
                                }
                                break;
                            }

                            case "3": { // Cancel
                                System.out.println("Cancel");
                                gp2.Cancel();
                                break;
                            }

                            case "4": { // Regular
                                System.out.println("Regular");
                                gp2.Regular();
                                break;
                            }

                            case "5": { // Premium
                                System.out.println("Premium");
                                gp2.Premium();
                                break;
                            }

                            case "6": { // Diesel
                                System.out.println("Diesel");
                                gp2.Diesel();
                                break;
                            }

                            case "7": { // Start
                                System.out.println("StartPump");
                                gp2.StartPump();
                                break;
                            }
                            case "8": { // PumpGallon
                                System.out.println("PumpGallon");
                                gp2.PumpGallon();
                                break;
                            }
                            case "9": { // Stop
                                System.out.println("Stop");
                                gp2.Stop();
                                break;
                            }
                            case "10": { // PrintReceipt
                                System.out.println("PrintReceipt");
                                gp2.Receipt();
                                break;
                            }
                            case "11": { // NoReceipt
                                System.out.println("NoReceipt");
                                gp2.NoReceipt();
                                break;
                            }
                            case "q": { // Quit
                                break;
                            }
                            default: { // Anything else: unknown / unsupported operation
                                System.out.println("Unknown operation: '" + input + "'");
                                System.out.println("Please enter a valid operation");
                                break;
                            }
                        }
                    } // End while loop
                    System.out.println("Quitting ...");
                    break;
                } // end pump_type = 2 case
                default: {// If an unknown GasPump type is selected
                    // Print error message and exit
                    System.out.println("Unknown GasPump selection. Terminating ...");
                    System.exit(1);
                }

            }
        } catch (IOException ioe) { // Catch IOException
            // Print error message and exit
            System.out.println("IO Error. Terminating ...");
            System.exit(1);
        }
    }
}