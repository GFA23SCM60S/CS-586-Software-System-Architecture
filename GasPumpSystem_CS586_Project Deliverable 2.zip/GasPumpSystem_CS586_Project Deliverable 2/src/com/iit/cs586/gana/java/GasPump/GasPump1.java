package GasPump;

import AbstractFactory.AbstractFactory;
import PlatformData.DataGasPump1;
import PlatformData.DataGasPump2;

/*
    This class is the InputProcessor for GasPump1
 */
public class GasPump1 extends GasPump {
    public GasPump1(AbstractFactory af) {
        super(af);
    }

    /*
        Print a menu of supported operations
     */
    @Override
    public void printOperations() {
        System.out.println("*********************************************");
        System.out.println("GP-1 Menu Of Operations");
        System.out.println("0. Activate(int a)");
        System.out.println("1. Start");
        System.out.println("2. PayCredit");
        System.out.println("3. PayCash(int c)");
        System.out.println("4. Reject");
        System.out.println("5. Cancel");
        System.out.println("6. Approved");
        System.out.println("7. StartPump");
        System.out.println("8. Pump");
        System.out.println("9. StopPump");
        System.out.println("q. Quit the Program");
        System.out.println("*********************************************");
    }

    /*
        Check the input parameters for correctness, and call the
        activate() meta-event of the EFSM model

        If input is incorrect, print a message indicating as such

     */
    /*
        Activate GasPump1 with a price parameter 'a', updating data and calling the activate() meta-event
     */
    public void Activate(int a) {
        if (a > 0) {
            DataGasPump1 d = (DataGasPump1) this.data;
            d.a = a;
            model.activate();
        } else {
            System.out.println("Activation failed!");
            System.out.println("Prices must be greater than $0");
        }
    }

    /*
        Call the start() meta-event of the EFSM model
     */
    /*
        Start the GasPump1 by calling the start() meta-event
     */
    public void Start() {
        model.start();
    }

    /*
        After checking input parameter for correctness,
        call the payType() meta-event of the EFSM model,
        passing in "2" as the payment type which represents cash payment under the model design

        If amount of cash inserted is less than zero, do not call the meta-event
        and print a message indicating input parameter requirements
     */
     /*
        Accept cash payment 'cash' for GasPump1, updating data and calling payType() meta-event
     */
    public void PayCash(int cash) {
        if (cash > 0) {
            DataGasPump1 d = (DataGasPump1) data;
            d.payType = 2;
            d.temp_cash = cash;
            model.payType(2);
        } else {
            System.out.println("Cash amount must be greater than $0");
        }
    }

    /*
        Call the payType() meta-event of the EFSM model,
        passing in "1" as the payment type which represents credit payment under the model design

        Also print a credit card authentication message
     */
    /*
        Accept credit card payment by calling payType() meta-event and print an authentication message
     */
    public void PayCredit() {
        DataGasPump1 d = (DataGasPump1) data;
        d.payType = 1;
        model.payType(1);
        System.out.println("PLEASE WAIT -- AUTHENTICATING CREDIT CARD");
    }
    // Methods for additional operations like Approve, Reject, Cancel, Regular, StartPump, Pump, StopPump

    /*
        Call the approve() meta-event of the EFSM model
     */
    public void Approve() {
        model.approve();
    }

    /*
        Call the reject() meta-event of the EFSM model
     */
    public void Reject() {
        model.reject();
    }

    /*
        Call the cancel() meta-event of the EFSM model
     */
    public void Cancel() {
        model.cancel();
    }

    /*
        Call the selectGas() meta-event of the EFSM model,
        passing in 1 as the gas-type
     */
    public void Regular() {
        model.selectGas(1);
    }
    /*
        Call the startPump() meta-event of the EFSM model
     */
    public void StartPump() {
        model.selectGas(1);
        model.startPump();
    }

    /*
        Call the pump() meta-event of the EFSM model
     */
    public void Pump() {
        DataGasPump1 d = (DataGasPump1) data;
        if (d.payType == 1) {
            model.pump();
        }
        else {
            if (d.cash < d.price * (d.L + 1)) {
                System.out.println("NOT ENOUGH CASH");
                model.stopPump();
                model.receipt();
            } else {
                model.pump();
            }
        }
    }

    /*
        call the stopPump() and receipt() meta-events of the EFSM model

        Note: GasPump1 always prints receipts after fuel is finished dispensing under current
        system design.
     */

    public void StopPump() {
        model.stopPump();
        model.receipt();
    }

}
