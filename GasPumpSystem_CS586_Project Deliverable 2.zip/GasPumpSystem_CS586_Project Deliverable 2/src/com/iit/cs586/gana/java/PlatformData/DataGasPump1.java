package PlatformData;

/*
    GasPump1 data storage object responsible for storing key platform-specific data that must be shared between
    system components

    NOTE: For the sake of shorter code and simplicity, fields are accessed directly, instead of through getters and setters
 */
public class DataGasPump1 extends Data {
    public int    cash;
    public int    price;
    public int L;
    public int    total;
    public int payType;

    // temporary variables
    public int a;
    public int temp_cash;

}
