package GasPump;

import AbstractFactory.AbstractFactory;
import Model.EFSM.StateMachine;
import Model.OutputProcessor.OutputProcessor;
import PlatformData.Data;

/*
    This abstract superclass implements the client-side of the Abstract Factory design pattern.
    It provides a constructor which subclasses can use to build up their drivers and necessary objects.

    Each child GasPump class will call this superclass's constructor passing in its own ConcreteFactory
    as the AbstractFactory field. The ConcreteFactory class makes sure each returned object has the proper
    object references
*/
// Constructor for GasPump class, taking an AbstractFactory as parameter
public abstract class GasPump {
    Data data;
    StateMachine model;


    // Constructor for GasPump class, taking an AbstractFactory as parameter
    GasPump(AbstractFactory af) {
        // Initialize data object using the AbstractFactory's method
        this.data = af.getDataObj();
        // Initialize model with a new StateMachine
        this.model = new StateMachine();
        // Set the OutputProcessor of the StateMachine with a new instance created using the AbstractFactory
        this.model.setOP(new OutputProcessor(af));
    }


    //Each GasPump must display a menu of its supported operations
    // Abstract method to print operations, to be implemented by subclasses
    public abstract void printOperations();

}
