package ActionStrategy.ReturnCash;

import PlatformData.Data;
import PlatformData.DataGasPump1;

/*
    GasPump1 ReturnCash action --> does nothing under current system design
 */
public class ReturnCash1 extends ReturnCash {

    public ReturnCash1(Data data) {
        super(data);
    }

    /*
        GasPump1 does not support payment with cash, and so this method should never be invoked
        by GasPump1 under the current system design.
        However, in the case that it does get invoked, it will do nothing.
    */
    @Override
    public void returnCash() {
        DataGasPump1 d = (DataGasPump1) data;
        float cash_return = d.cash - d.total;
        if (cash_return > 0) {
            System.out.println("Cash to return: $" + cash_return);
            System.out.println("Returning $" + cash_return);
        } else {
            System.out.println("No cash to return");
        }
        d.cash = 0;
        System.out.println("Transaction finished");
    }
}
