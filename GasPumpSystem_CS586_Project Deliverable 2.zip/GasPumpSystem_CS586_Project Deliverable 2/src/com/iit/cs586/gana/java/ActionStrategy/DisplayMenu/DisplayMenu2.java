package ActionStrategy.DisplayMenu;

import PlatformData.Data;
import PlatformData.DataGasPump2;

/*
    GasPump2 DisplayMenu action responsible for printing the main menu
 */
public class DisplayMenu2 extends DisplayMenu {

    public DisplayMenu2(Data data) {
        super(data);
    }

    /*
        Print a menu
        Also reads the data structure to inform the user of current gas prices
     */
    @Override
    public void displayMenu() {
        DataGasPump2 d = (DataGasPump2) data;
        System.out.println("Please select gas type: ");
        System.out.println(
                "(4) Regular [$" + d.R_price + "/Gallon] " +
                        "\n(5) Premium [$" + d.P_price + "/Gallon] " +
                        "\n(6) Diesel [$" + d.D_price + "/Gallon]");
        System.out.println("Otherwise, select (3) to cancel");
    }
}
